module.exports = {
    HOST: "localhost",
    USER: "admin",
    PASSWORD: "hello",
    DB: "contactdb"
}
